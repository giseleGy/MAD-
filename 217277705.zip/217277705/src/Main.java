import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner inputText = new Scanner(System.in);

        double GS = 10000, rate = 100, totalPay, hrs, deduction;

        String name,type;

        System.out.println ("Enter employee's name");

        name = inputText.nextLine();

        System.out.println ("Enter type A (Monthly), B (Weekly), C (Hourly)");

        type = inputText.nextLine();

        if (type.equals("A") || type.equals("a")){

            deduction = (GS * 0.3) + (GS * 0.03);

            totalPay = GS - deduction;

            System.out.println("Names : " + name);
            System.out.println("\nType : " + type);
            System.out.println("\nTotal pay : " + totalPay);


        }else if (type.equals("B") || type.equals("b")){

            deduction = (GS * 0.03);

            totalPay = GS - deduction;

            System.out.println("Names : " + name);
            System.out.println("\nType : " + type);
            System.out.println("\nTotal pay : " + totalPay);

        }else{

            System.out.println ("Number of hours");

            hrs = Double.parseDouble(inputText.nextLine());

            totalPay = rate * hrs;

            System.out.println("Names : " + name);
            System.out.println("\nType : " + type);
            System.out.println("\nTotal pay : " + totalPay);

        }
    }
}
